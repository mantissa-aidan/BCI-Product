% EEG_example - following instructions in pdf
close all
clear all
[data,Fs] = audioread('TimBrain_VisualCortex_BYB_Recording.wav');
data_new = downsample(data,20);
data_new_2 = decimate(data,20);

spectrogram(data_new,256,250,256,500,'yaxis');
ylim([0 90]);
colormap(winter);
brighten(-0.7);

%%

[d,f,t]=spectrogram(data_new,256,250,256,500,'yaxis');
d_real=real(d);
AlphaRange = mean(d_real((5:7),:),1);
Smoothed_AlphaRange=smooth((abs(AlphaRange)),250,'moving');
figure;
plot(t/60,Smoothed_AlphaRange);
xlim([0 max(t/60)]);