function testStat = GiveTestStat(X)
% Given does the signal, X, have an event?

% We're looking for a strong gradient in one direction and then a strong gradient
% in the other direction

N = length(X);

% Split in two:
% X1 = X(1:floor(N/2));
% X2 = X(floor(N/2)+1:end);

% Compute median gradients:
testStat = median(diff(X));
% m2 = mean(diff(X2));

% Get statistic:
% testStat = m1 - m2;

end
