% Simple classifier of events in a recorded audio waveform

whatRecording = 'example1';

%-------------------------------------------------------------------------------
% Load in data and event vector
switch whatRecording
case 'example1'
    [Y,Fs] = audioread('BYB_Recording_2019-01-18_18.01.34.wav');
    eventTime = [7.4,14.8,19.2,23.3,26.8,31.8,36.2,46,49.6,53,57.1]';
    eventType = categorical({'R','L','L','R','R','L','L','R','R','L','L'}');
    eventTable = table(eventTime,eventType);
case 'example2'
    [Y,Fs] = audioread('BYB_Recording_2019-01-18_18.15.16.wav');

    eventTime = [4,7,11,14,18,23,26,31,34,37,41,44,46,54,57]';
    eventType = categorical({'R','R','L','R','L','LR','R','R','L','L','L','R','L','R','R'}');
    % A left-right at 23s
end

% Time vector (s)
T = [1:length(Y)]/Fs;
numEvents = height(eventTable);

%-------------------------------------------------------------------------------
% Plot the data:
figure('color','w');
hold('on');
plot(T,Y,'k')
for i = 1:numEvents
    r = eventTable.eventTime(i) + [-0.5,+0.5];
    isEvent = (T > r(1) & T < r(2));
    if eventTable.eventType(i)=='R'
        theColor = 'r';
    else
        theColor = 'b';
    end
    plot(T(isEvent),Y(isEvent),'color',theColor);
end

xlabel('time [s]')
ylabel('signal [a.u.]')

%-------------------------------------------------------------------------------
% Another one based on zero crossing events:

% Whenever a window of duration D has fewer than X crossing events:
windowSize = 1.1; % 1.1s
thresholdEvents = 15*windowSize; % fewer than 15 events per second

zeroCrossingTimes = T(Y(1:end-1).*Y(2:end) <= 0);
ind = 1:find(T>T(end)-windowSize,1,'first');
% downsample for speed:
downSampleRate = 50;
ind = ind(1:downSampleRate:end);
timeMiddle = T(ind)+windowSize/2; % time vector for middle of each window
testStat = nan(length(ind),1);
for i = 1:length(ind)
    testStat(i) = sum(zeroCrossingTimes>=T(ind(i)) & ...
                            zeroCrossingTimes < T(ind(i))+windowSize);
end
predictedEvent = find(testStat<thresholdEvents);

% Cluster predicted events that are within some time window from each other
deltaSameEvent = windowSize; % 1s
eventTimes = timeMiddle(predictedEvent);
while any(diff(eventTimes) < deltaSameEvent)
    tryHere = find(diff(eventTimes) < deltaSameEvent,1,'first');
    isCluster = (eventTimes >= eventTimes(tryHere)) & ...
                     (eventTimes < eventTimes(tryHere)+deltaSameEvent);
    clusterEvent = round(mean(predictedEvent(isCluster)));
    predictedEvent(isCluster) = [];
    predictedEvent = sort([predictedEvent;clusterEvent]);
    eventTimes = timeMiddle(predictedEvent);
end

% Mark each event as either L or R
numEvents = length(predictedEvent);
testStat = zeros(numEvents,1);
for i = 1:numEvents
    % Sign of largest peak in time window
    iLower = find(T>eventTimes(i)-windowSize/2,1,'first');
    iUpper = find(T>eventTimes(i)+windowSize/2,1,'first');
    X = Y(iLower:iUpper);
    [~,isMax] = max(abs(X));
    testStat(i) = X(isMax);
    % Compute mean gradient for windowSize/2 before and after event
    % X1 = Y(iLower:predictedEvent(i));
    % X2 = Y(predictedEvent(i):iUpper);
    % m1 = mean(diff(X1)); m2 = mean(diff(X2));
    % testStat(i) = m1 - m2;
end

%-------------------------------------------------------------------------------
% Mark predicted events on the waveform:
figure('color','w'); hold('on');
plot(T,Y,'k')
numEvents = height(eventTable);
for i = 1:numEvents
    r = eventTable.eventTime(i) + [-0.5,+0.5];
    isEvent = (T > r(1) & T < r(2));
    if eventTable.eventType(i)=='R'
        theColor = 'r';
    else
        theColor = 'b';
    end
    plot(T(isEvent),Y(isEvent),'color',theColor);
end
plot(timeMiddle(predictedEvent(testStat>0)),testStat(testStat>0),'ob','MarkerSize',15)
plot(timeMiddle(predictedEvent(testStat<0)),testStat(testStat<0),'or','MarkerSize',15)

%===============================================================================

% f = figure('color','w');
% plot(timeMiddle,testStat,'ok')
%
% f = figure('color','w');
% hold('on')
% plot(T,Y,'.k')
% plot(T(1:end-1),100*Y(1:end-1).*Y(2:end),'.r')
%
% %-------------------------------------------------------------------------------
% % Let's try a very simple classifier
% windowSize = 0.1;
% ind = 1:find(T==T(end)-windowSize);
% % downsample for speed:
% downSampleRate = 25;
% ind = ind(1:downSampleRate:end);
% timeMiddle = T(ind)+windowSize/2; % time vector for middle of each window
% testStat = nan(length(ind),1);
% for i = 1:length(ind)
%     testStat(i) = GiveTestStat(Y(ind(i):find(T==T(ind(i))+windowSize)));
% end
%
% % Set a threshold on the test statistic:
% omega = 3e-5; % (s)
% % Test statistic passes this threshold:
% passUp = ((testStat(1:end-1)-omega).*(testStat(2:end)-omega) < 0);
% passDown = ((testStat(1:end-1)+omega).*(testStat(2:end)+omega) < 0);
% timeUp = timeMiddle(passUp);
% timeDown = timeMiddle(passDown);
% % Mark these events on the waveform:
% figure('color','w'); hold('on');
% plot(T,Y,'k')
% for i = 1:numEvents
%     r = eventTable.eventTime(i) + [-0.5,+0.5];
%     isEvent = (T > r(1) & T < r(2));
%     if eventTable.eventType(i)=='R'
%         theColor = 'r';
%     else
%         theColor = 'b';
%     end
%     plot(T(isEvent),Y(isEvent),'color',theColor);
% end
% plot(timeUp,zeros(length(timeUp),1),'or','MarkerSize',15)
% plot(timeDown,zeros(length(timeDown),1),'ob','MarkerSize',15)
